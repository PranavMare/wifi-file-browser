// client/src/components/FullscreenViewer.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";

export default function FullscreenViewer({ open, items, index, setIndex, onClose }) {
  const valid = Array.isArray(items) && items.length > 0;
  const total = valid ? items.length : 0;
  const safeIndex = valid ? ((index % total) + total) % total : 0;
  const item = valid ? items[safeIndex] : null;

  // Refs & state
  const wrapRef = useRef(null); // outer full-screen container
  const stageRef = useRef(null); // slides left/right/up/down as one unit
  const imgRef = useRef(null); // image element

  const natural = useRef({ w: 0, h: 0 });
  const view = useRef({ base: 1, zoom: 1, x: 0, y: 0 }); // pan+zoom
  const slide = useRef({ x: 0, y: 0, opacity: 1 }); // swipe nav/close

  const pointers = useRef(new Map()); // pointerId -> {x,y}
  const pinchStart = useRef(null); // {dist, zoom, center:{x,y}}
  const dragStart = useRef(null); // {x,y, vx, vy, t}
  const lastTap = useRef({ t: 0, x: 0, y: 0 });
  const tapCandidate = useRef(false);

  const [chrome, setChrome] = useState(true);
  const [loading, setLoading] = useState(true);
  const hideTimer = useRef(null);

  const prevStyles = useRef({ overflow: "", position: "", top: "", left: "", right: "", width: "" });
  const scrollYRef = useRef(0);

  const ZMIN = 0.1,
    ZMAX = 6; // zoom bounds
  const SWIPE_PX = 70; // swipe distance threshold
  const SWIPE_VX = 0.45; // swipe velocity (px/ms) threshold
  const CLOSE_PY = 90; // swipe-down to close threshold
  const CLOSE_VY = 0.5;

  // Helpers ------------------------------------------------------------
  const showChromeSoonHide = () => {
    setChrome(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setChrome(false), 3000); // Increased for better UX
  };

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rectPoint = (e) => {
    const r = wrapRef.current.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top, t: e.timeStamp || Date.now() };
  };
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });

  const computeFit = () => {
    const c = wrapRef.current;
    const { w, h } = natural.current;
    if (!c || !w || !h) return 1;
    return Math.min(c.clientWidth / w, c.clientHeight / h) || 1;
  };

  const renderImage = () => {
    const el = imgRef.current;
    if (!el) return;
    const v = view.current;
    el.style.transform = `translate3d(${v.x}px, ${v.y}px, 0) scale(${v.zoom})`;
  };

  const renderStage = () => {
    const st = stageRef.current;
    if (!st) return;
    const s = slide.current;
    st.style.transform = `translate3d(${s.x}px, ${s.y}px, 0)`;
    st.style.opacity = s.opacity;
  };

  const setStageTransition = (on) => {
    const st = stageRef.current;
    if (!st) return;
    st.style.transition = on ? "transform 180ms ease, opacity 180ms ease" : "none";
  };

  const animateTo = (x, y, opacity = 1, cb) => {
    setStageTransition(true);
    slide.current = { x, y, opacity };
    renderStage();
    const done = () => {
      setStageTransition(false);
      stageRef.current?.removeEventListener("transitionend", done);
      cb && cb();
    };
    stageRef.current?.addEventListener("transitionend", done);
  };

  const zoomAround = (factor, pivot) => {
    const v = view.current;
    const zPrev = v.zoom;
    const zNew = clamp(zPrev * factor, ZMIN, ZMAX);
    const ratio = zNew / zPrev;
    v.x = v.x * ratio + pivot.x * (1 - ratio);
    v.y = v.y * ratio + pivot.y * (1 - ratio);
    v.zoom = zNew;
    renderImage();
  };

  // Lifecycle ----------------------------------------------------------
  useEffect(() => {
    // Clear hide timer on unmount
    return () => {
      clearTimeout(hideTimer.current);
    };
  }, []);

  useEffect(() => {
    // new image -> reset
    setLoading(true);
    setChrome(true);
    clearTimeout(hideTimer.current);
    slide.current = { x: 0, y: 0, opacity: 1 };
    renderStage();
    view.current = { base: 1, zoom: 1, x: 0, y: 0 };
    renderImage();

    // preload neighbors
    if (valid) {
      const n = new Image();
      n.src = items[(safeIndex + 1) % total]?.src || "";
      const p = new Image();
      p.src = items[(safeIndex - 1 + total) % total]?.src || "";
    }
  }, [safeIndex, valid, items, total]);

  useEffect(() => {
    // fit-on-resize (only when at base)
    const onResize = () => {
      const base = computeFit();
      const atBase = Math.abs(view.current.zoom - view.current.base) < 0.01;
      view.current.base = base;
      if (atBase) {
        view.current.zoom = base;
        view.current.x = 0;
        view.current.y = 0;
        renderImage();
      }
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // Keyboard (desktop fallback)
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") onClose?.();
      if (e.key === "ArrowLeft") setIndex(safeIndex - 1);
      if (e.key === "ArrowRight") setIndex(safeIndex + 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [safeIndex, setIndex, onClose]);

  useEffect(() => {
    if (!open) {
      // ensure unlock on close - restore all body styles
      document.body.style.overflow = prevStyles.current.overflow || "";
      document.body.style.position = prevStyles.current.position || "";
      document.body.style.top = prevStyles.current.top || "";
      document.body.style.left = prevStyles.current.left || "";
      document.body.style.right = prevStyles.current.right || "";
      document.body.style.width = prevStyles.current.width || "";

      // restore scroll position
      if (typeof scrollYRef.current === "number") {
        // Use requestAnimationFrame to ensure DOM is updated before scrolling
        requestAnimationFrame(() => {
          window.scrollTo(0, scrollYRef.current);
        });
      }
      return;
    }

    // save current inline styles (so we don't clobber other code)
    prevStyles.current = {
      overflow: document.body.style.overflow,
      position: document.body.style.position,
      top: document.body.style.top,
      left: document.body.style.left,
      right: document.body.style.right,
      width: document.body.style.width,
    };

    // lock + preserve scroll position (mobile-safe)
    scrollYRef.current = window.scrollY || window.pageYOffset || 0;
    document.body.style.overflow = "hidden";
    document.body.style.position = "fixed";
    document.body.style.top = `-${scrollYRef.current}px`;
    document.body.style.left = "0";
    document.body.style.right = "0";
    document.body.style.width = "100%";

    return () => {
      // cleanup if component unmounts while open
      document.body.style.overflow = prevStyles.current.overflow || "";
      document.body.style.position = prevStyles.current.position || "";
      document.body.style.top = prevStyles.current.top || "";
      document.body.style.left = prevStyles.current.left || "";
      document.body.style.right = prevStyles.current.right || "";
      document.body.style.width = prevStyles.current.width || "";

      requestAnimationFrame(() => {
        window.scrollTo(0, scrollYRef.current || 0);
      });
    };
  }, [open]);

  // Events -------------------------------------------------------------
  const onImgLoad = () => {
    const el = imgRef.current;
    if (!el) return;
    natural.current = { w: el.naturalWidth || 0, h: el.naturalHeight || 0 };
    const base = computeFit();
    view.current.base = base;
    view.current.zoom = base;
    view.current.x = 0;
    view.current.y = 0;
    renderImage();
    setLoading(false);
    showChromeSoonHide();
  };

  const onWheel = (e) => {
    // Don't interfere with UI elements
    if (e.target.closest("button") || e.target.closest("a") || e.target.closest('[role="button"]')) {
      return;
    }

    e.preventDefault();
    e.stopPropagation();
    showChromeSoonHide();
    const p = rectPoint(e);
    zoomAround(e.deltaY > 0 ? 1 / 1.1 : 1.1, p);
  };

  const onPointerDown = (e) => {
    // Don't interfere with button clicks and UI elements
    if (e.target.closest("button") || e.target.closest("a") || e.target.closest('[role="button"]')) {
      return;
    }

    e.preventDefault();
    e.stopPropagation();

    wrapRef.current?.setPointerCapture(e.pointerId);
    const p = rectPoint(e);
    pointers.current.set(e.pointerId, p);
    tapCandidate.current = true;

    // double-tap zoom (touch)
    if (e.pointerType === "touch") {
      const now = Date.now();
      const last = lastTap.current;
      if (now - last.t < 280 && Math.hypot(p.x - last.x, p.y - last.y) < 24) {
        const base = view.current.base;
        const target = Math.abs(view.current.zoom - base) < 0.01 ? base * 2.5 : base;
        zoomAround(target / view.current.zoom, p);
        lastTap.current = { t: 0, x: 0, y: 0 };
        return;
      }
      lastTap.current = { t: now, x: p.x, y: p.y };
    }

    // start drag or pinch
    if (pointers.current.size === 1) {
      dragStart.current = { x: p.x, y: p.y, vx: view.current.x, vy: view.current.y, t: p.t };
    } else if (pointers.current.size === 2) {
      const [a, b] = Array.from(pointers.current.values());
      pinchStart.current = { dist: dist(a, b), zoom: view.current.zoom, center: mid(a, b) };
    }

    showChromeSoonHide();
  };

  const onPointerMove = (e) => {
    if (!pointers.current.has(e.pointerId)) return;

    // Only prevent default for actual pointer interactions, not UI elements
    if (!e.target.closest("button") && !e.target.closest("a") && !e.target.closest('[role="button"]')) {
      e.preventDefault();
      e.stopPropagation();
    }

    const p = rectPoint(e);
    pointers.current.set(e.pointerId, p);

    // If finger moved, it's not a simple tap anymore
    if (dragStart.current) {
      if (Math.abs(p.x - dragStart.current.x) + Math.abs(p.y - dragStart.current.y) > 6) {
        tapCandidate.current = false;
      }
    }

    // Pinch zoom
    if (pointers.current.size === 2 && pinchStart.current) {
      const [a, b] = Array.from(pointers.current.values());
      const dNow = dist(a, b);
      const cNow = mid(a, b);
      const zTarget = clamp((dNow / Math.max(1, pinchStart.current.dist)) * pinchStart.current.zoom, ZMIN, ZMAX);
      const ratio = zTarget / view.current.zoom;
      view.current.x = view.current.x * ratio + cNow.x * (1 - ratio);
      view.current.y = view.current.y * ratio + cNow.y * (1 - ratio);
      view.current.zoom = zTarget;
      renderImage();
      return;
    }

    // Single finger: pan or prepare swipe
    if (pointers.current.size === 1 && dragStart.current) {
      const base = view.current.base;
      const atBase = Math.abs(view.current.zoom - base) < 0.06;
      const dx = p.x - dragStart.current.x;
      const dy = p.y - dragStart.current.y;

      if (!atBase) {
        // Pan image
        view.current.x = dragStart.current.vx + dx;
        view.current.y = dragStart.current.vy + dy;
        renderImage();
      } else {
        // Swipe nav / close (move stage)
        slide.current = {
          x: Math.abs(dx) > Math.abs(dy) ? dx : 0,
          y: Math.abs(dy) >= Math.abs(dx) ? dy : 0,
          opacity: Math.abs(dy) > Math.abs(dx) ? clamp(1 - Math.abs(dy) / 220, 0.35, 1) : 1,
        };
        renderStage();
      }
    }
  };

  const onPointerUpOrCancel = (e) => {
    // Don't interfere with button clicks and UI elements
    if (!e.target.closest("button") && !e.target.closest("a") && !e.target.closest('[role="button"]')) {
      e.preventDefault();
      e.stopPropagation();
    }

    const p = pointers.current.get(e.pointerId);
    pointers.current.delete(e.pointerId);
    wrapRef.current?.releasePointerCapture(e.pointerId);
    if (pointers.current.size < 2) pinchStart.current = null;

    // Tap toggles chrome if no movement
    if (tapCandidate.current && e.pointerType !== "mouse") {
      setChrome((v) => {
        const next = !v;
        clearTimeout(hideTimer.current);
        if (next) showChromeSoonHide();
        return next;
      });
    }

    // Decide swipe action only when single finger finished
    if (p && dragStart.current && pointers.current.size === 0) {
      const base = view.current.base;
      const atBase = Math.abs(view.current.zoom - base) < 0.06;
      const dx = p.x - dragStart.current.x;
      const dy = p.y - dragStart.current.y;
      const dt = Math.max(1, p.t - dragStart.current.t);
      const vx = dx / dt; // px/ms
      const vy = dy / dt;

      if (atBase) {
        // Horizontal swipe → next/prev
        if (Math.abs(dx) > SWIPE_PX || Math.abs(vx) > SWIPE_VX) {
          const dir = dx < 0 ? -1 : 1; // negative dx => swiped left => next
          const w = wrapRef.current.clientWidth;
          animateTo(dir * w, 0, 1, () => {
            slide.current = { x: 0, y: 0, opacity: 1 };
            renderStage();
            setIndex(safeIndex - dir); // note the sign flip
          });
          dragStart.current = null;
          return;
        }
        // Vertical swipe down → close
        if (dy > CLOSE_PY || vy > CLOSE_VY) {
          const h = wrapRef.current.clientHeight;
          animateTo(0, h, 0.2, () => {
            slide.current = { x: 0, y: 0, opacity: 1 };
            renderStage();
            onClose?.();
          });
          dragStart.current = null;
          return;
        }
        // Otherwise, snap back
        animateTo(0, 0, 1);
      }
    }

    dragStart.current = null;
  };

  // UI classes - Modern design with improved styling
  const baseBtn = "relative overflow-hidden transition-all duration-200 ease-out transform-gpu";
  const primaryBtn = `${baseBtn} h-10 px-4 rounded-xl text-sm font-medium border border-white/20 bg-white/10 backdrop-blur-xl hover:bg-white/20 hover:border-white/30 active:scale-[0.96] active:bg-white/25 shadow-lg`;
  const iconBtn = `${baseBtn} h-10 w-10 rounded-xl border border-white/20 bg-white/10 backdrop-blur-xl hover:bg-white/20 hover:border-white/30 active:scale-[0.96] active:bg-white/25 shadow-lg flex items-center justify-center`;
  const closeBtn = `${baseBtn} h-10 w-10 rounded-xl border border-red-400/30 bg-red-500/20 backdrop-blur-xl hover:bg-red-500/30 hover:border-red-400/50 active:scale-[0.96] shadow-lg flex items-center justify-center text-red-100`;
  const hud = chrome ? "opacity-100 translate-y-0" : "opacity-0 pointer-events-none translate-y-2";

  if (!open || !item) return null;

  return (
    <div
      ref={wrapRef}
      className="fixed inset-0 z-[9999] bg-black text-white select-none"
      style={{ touchAction: "none" }}
      onWheel={onWheel}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUpOrCancel}
      onPointerCancel={onPointerUpOrCancel}
      role="dialog"
      aria-modal="true"
      aria-label={item.name ? `Viewing ${item.name}` : "Viewer"}
    >
      {/* Stage (moves for swipes) */}
      <div ref={stageRef} className="absolute inset-0 flex items-center justify-center will-change-transform">
        {loading && (
          <div className="absolute inset-0 grid place-items-center bg-black/50 backdrop-blur-sm">
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <div className="h-12 w-12 rounded-full border-2 border-white/20" />
                <div className="absolute inset-0 h-12 w-12 rounded-full border-2 border-transparent border-t-white animate-spin" />
              </div>
              <div className="text-sm font-medium text-white/80">Loading image...</div>
            </div>
          </div>
        )}
        <img
          ref={imgRef}
          src={item.src}
          alt={item.name || ""}
          onLoad={onImgLoad}
          className="max-w-none max-h-none pointer-events-none select-none transition-opacity duration-300"
          draggable={false}
          style={{
            transform: `translate3d(${view.current.x}px, ${view.current.y}px, 0) scale(${view.current.zoom})`,
            opacity: loading ? 0 : 1,
          }}
        />
      </div>

      {/* Top bar with gradient overlay */}
      <div className={`absolute left-0 right-0 top-0 bg-gradient-to-b from-black/60 via-black/30 to-transparent ${hud} transition-all duration-300`}>
        <div className="p-4 pt-[calc(env(safe-area-inset-top)+1rem)] flex items-center justify-between" onClick={(e) => e.stopPropagation()}>
          {/* File info with improved typography */}
          <div className="flex items-center gap-3">
            <div className="bg-white/10 backdrop-blur-xl rounded-xl px-4 py-2 border border-white/20 shadow-lg">
              <div className="text-sm font-semibold text-white">{item.name || "Untitled"}</div>
              {valid && (
                <div className="text-xs text-white/70 mt-0.5">
                  {safeIndex + 1} of {total}
                </div>
              )}
            </div>
          </div>

          {/* Navigation and action buttons */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-white/5 backdrop-blur-xl rounded-xl p-1 border border-white/10">
              <button className={iconBtn} onClick={() => setIndex(safeIndex - 1)} aria-label="Previous image" title="Previous (←)">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <button className={iconBtn} onClick={() => setIndex(safeIndex + 1)} aria-label="Next image" title="Next (→)">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <a href={item.download} className={primaryBtn} title="Download image">
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
                Download
              </a>
              <button
                className={primaryBtn}
                onClick={() => {
                  const url = new URL(item.src, location.origin).toString();
                  if (navigator.share) navigator.share({ title: item.name, url }).catch(() => {});
                  else navigator.clipboard?.writeText(url).catch(() => {});
                }}
                title="Share image"
              >
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z"
                  />
                </svg>
                Share
              </button>
              <button className={closeBtn} onClick={() => onClose?.()} aria-label="Close viewer" title="Close (Esc)">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom controls with gradient overlay */}
      <div className={`absolute left-0 right-0 bottom-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent ${hud} transition-all duration-300`}>
        <div className="p-4 pb-[calc(env(safe-area-inset-bottom)+1rem)] flex items-center justify-center" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-xl rounded-xl p-2 border border-white/20 shadow-lg">
            <button
              className={primaryBtn}
              onClick={() => {
                const base = view.current.base;
                const target = Math.abs(view.current.zoom - base) < 0.01 ? base * 2 : base;
                const pivot = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
                zoomAround(target / view.current.zoom, pivot);
                showChromeSoonHide();
              }}
              title="Toggle zoom"
            >
              {Math.abs(view.current.zoom - view.current.base) < 0.01 ? (
                <>
                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7"
                    />
                  </svg>
                  Zoom In
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" />
                  </svg>
                  Fit to Screen
                </>
              )}
            </button>
            <button
              className={primaryBtn}
              onClick={() => {
                view.current.x = 0;
                view.current.y = 0;
                view.current.zoom = view.current.base;
                renderImage();
                showChromeSoonHide();
              }}
              title="Reset view"
            >
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                />
              </svg>
              Reset
            </button>
          </div>
        </div>
      </div>

      {/* Touch hints for mobile */}
      {!loading && (
        <div
          className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none ${
            chrome ? "opacity-0" : "opacity-30"
          } transition-opacity duration-500`}
        >
          <div className="text-center text-white/60 text-sm">
            <div>Tap to show controls</div>
            <div className="text-xs mt-1">Pinch to zoom • Swipe to navigate</div>
          </div>
        </div>
      )}
    </div>
  );
}
